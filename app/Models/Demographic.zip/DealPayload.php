<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class DealPayload extends Model
{
    use HasFactory;

    protected $fillable = [
        'deal_id', 
        'name', 
        'deal_unit', 
        'demo', 
        'ae', 
        'demo_population', 
        'impressions', 
        'grp', 
        'cpm', 
        'hh_rating', 
        'hh_ss', 
        'hh_cpm', 
        'hh_univ', 
        'a25_49_rating', 
        'a25_49_ss', 
        'a25_49_cpm', 
        'a25_49_univ', 
        'flight_start_date', 
        'flight_end_date', 
        'sunday', 
        'monday', 
        'tuesday', 
        'wednesday', 
        'thursday', 
        'friday', 
        'saturday', 
        'sunday_split', 
        'monday_split', 
        'tuesday_split', 
        'wednesday_split', 
        'thursday_split', 
        'friday_split', 
        'saturday_split', 
        'inventory_type', 
        'inventory_length', 
        'rate', 
        'rc_rate', 
        'rc_rate_percentage', 
        'total_avil', 
        'total_unit', 
        'unit', 
        'created_throught', 
        'tape_id', 
        'change_by', 
        'change_throught', 
        'status', 
        'delete', 
        'created_by', 
        'updated_by', 
        'created_at', 
        'updated_at',
    ];

}
